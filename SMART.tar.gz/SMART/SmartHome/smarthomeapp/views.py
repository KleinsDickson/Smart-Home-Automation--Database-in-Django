# smarthomeapp/views.py
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.decorators import login_required
from .models import UserProfile

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
        
            UserProfile.objects.create(user=user)
            return redirect('login') 
    else:
        form = UserCreationForm()
    return render(request, 'smarthomeapp/register.html', {'form': form})

@login_required
def profile(request):
    user_profile = UserProfile.objects.get(user=request.user)
    return render(request, 'smarthomeapp/profile.html', {'user_profile': user_profile})

# views.py

from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from firebase_admin import db

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            
            user = form.save()
            
            create_firebase_user_node(user)

            return redirect('login')  
    else:
        form = UserCreationForm()
    return render(request, 'smarthomeapp/register.html', {'form': form})

def home(request):
    return render (request, "home.html")

def create_firebase_user_node(user):
    
    database = db.reference()

    user_node_path = f'users/{user.id}'

    database.child(user_node_path).set({
        'email': user.email,
        'username': user.username,
    })

@login_required
def profile(request):

    user_profile = get_object_or_404(UserProfile, user=request.user)

    additional_data = {
        'rfid_card_info': user_profile.rfid_card_info,
    
    }

    context = {
        'user_profile': user_profile,
        'additional_data': additional_data,
    }

    return render(request, 'smarthomeapp/profile.html', context)

#DEVICES

from django.shortcuts import render
from firebase_admin import db
from .models import Device

def add_device(request):
    device_id = "rfid_card_2"
    device_type = "RFID"
    configuration = {
        "frequency": "13.56 MHz",
        "range": "Medium"
    }

    write_device_to_firebase(device_id, device_type, configuration)


def write_device_to_firebase(device_id, device_type, configuration):
    database = db.reference()
    device_node_path = f'devices/{device_id}'

    database.child(device_node_path).set({
        'type': device_type,
        'configuration': configuration
    })
    
#user add


from django.shortcuts import render
from firebase_admin import db

def add_user(request):
    uid = "uid_6"
    username = "user_six"
    email = "user_six@example.com"
    profile_picture = "/home/kleins/Desktop/SMART/SmartHome/smarthomeapp/images/danny.jpg"
    other_field = "some_value"

    write_user_to_firebase(uid, username, email, profile_picture, other_field)


def write_user_to_firebase(uid, username, email, profile_picture, other_field):
    database = db.reference()
    user_node_path = f'users/{uid}'

    database.child(user_node_path).set({
        'username': username,
        'email': email,
        'profile_picture': profile_picture,
        'other_field': other_field
    })

#Energy logs

from django.shortcuts import render
from firebase_admin import db
from datetime import datetime

def add_energy_log(request, energy_consumed):
    timestamp = int(datetime.now().timestamp())
    write_energy_log_to_firebase(timestamp, energy_consumed)


def write_energy_log_to_firebase(timestamp, energy_consumed):
    database = db.reference()
    energy_logs_path = f'energy_logs/{timestamp}'

    database.child(energy_logs_path).set({
        'timestamp': timestamp,
        'energy_consumed': energy_consumed
    })

from .models import EnergyLog

def add_energy_log(request, energy_consumed):
    timestamp = int(datetime.now().timestamp())
    EnergyLog.objects.create(timestamp=timestamp, energy_consumed=energy_consumed)

 #Security events

from django.shortcuts import render
from firebase_admin import db
from datetime import datetime

def add_security_event(request, event_type, details):
    timestamp = int(datetime.now().timestamp())
    write_security_event_to_firebase(timestamp, event_type, details)


def write_security_event_to_firebase(timestamp, event_type, details):
    database = db.reference()
    security_events_path = f'security_events/{timestamp}'

    database.child(security_events_path).set({
        'timestamp': timestamp,
        'event_type': event_type,
        'details': details
    })

from .models import SecurityEvent

def add_security_event(request, event_type, details):
    timestamp = int(datetime.now().timestamp())
    SecurityEvent.objects.create(timestamp=timestamp, event_type=event_type, details=details)

#Environmental data

from django.shortcuts import render
from firebase_admin import db
from datetime import datetime

def add_environmental_data(request, temperature, humidity, pir_sensor_value, mq2_sensor_value):
    timestamp = int(datetime.now().timestamp())
    write_environmental_data_to_firebase(timestamp, temperature, humidity, pir_sensor_value, mq2_sensor_value)


def write_environmental_data_to_firebase(timestamp, temperature, humidity, pir_sensor_value, mq2_sensor_value):
    database = db.reference()
    environmental_data_path = f'environmental_data/{timestamp}'

    database.child(environmental_data_path).set({
        'timestamp': timestamp,
        'temperature': temperature,
        'humidity': humidity,
        'pir_sensor_value': pir_sensor_value,
        'mq2_sensor_value': mq2_sensor_value
    })
    

from .models import EnvironmentalData

def add_environmental_data(request, temperature, humidity, pir_sensor_value, mq2_sensor_value):
    timestamp = int(datetime.now().timestamp())
    EnvironmentalData.objects.create(
        timestamp=timestamp,
        temperature=temperature,
        humidity=humidity,
        pir_sensor_value=pir_sensor_value,
        mq2_sensor_value=mq2_sensor_value
    )
    
