from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin, Group, Permission
from django.db import models
from django.utils.translation import gettext_lazy as _

class UserProfileManager(BaseUserManager):
    def create_user(self, email, username, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, username=username, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, username, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, username, password, **extra_fields)

class UserProfile(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True)
    username = models.CharField(max_length=30, unique=True)
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True)
    rfid_card_info = models.CharField(max_length=50, null=True, blank=True)

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    # Set custom related_name for groups
    groups = models.ManyToManyField(
        Group,
        verbose_name=_('groups'),
        blank=True,
        related_name='userprofile_groups',
        related_query_name='userprofile_group',
    )

    # Set custom related_name for user_permissions
    user_permissions = models.ManyToManyField(
        Permission,
        verbose_name=_('user permissions'),
        blank=True,
        related_name='userprofile_user_permissions',
        related_query_name='userprofile_user_permission',
    )

    objects = UserProfileManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    def __str__(self):
        return self.username

# Sensor DATA
class Device(models.Model):
    user_profile = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    pir_sensor_value = models.FloatField()
    mq2_sensor_value = models.FloatField()
    temperature_value = models.FloatField()
    humidity_value = models.FloatField()
    rfid_tag_id = models.CharField(max_length=50, null=True, blank=True)

#Energy logs


from django.db import models

class EnergyLog(models.Model):
    timestamp = models.IntegerField(unique=True)
    energy_consumed = models.FloatField()

    def __str__(self):
        return f'Energy Log at {self.timestamp}'
    
#security events

from django.db import models

class SecurityEvent(models.Model):
    timestamp = models.IntegerField(unique=True)
    event_type = models.CharField(max_length=255)
    details = models.TextField()

    def __str__(self):
        return f'Security Event at {self.timestamp}'
    
#Environmental data


from django.db import models

class EnvironmentalData(models.Model):
    timestamp = models.IntegerField(unique=True)
    temperature = models.FloatField()
    humidity = models.FloatField()
    pir_sensor_value = models.FloatField()
    mq2_sensor_value = models.FloatField()

    def __str__(self):
        return f'Environmental Data at {self.timestamp}'
